let state = { incidents: [], officers: [], sites: [], tours: [], activity: [], incidentFilter: 'All', demoDataControls: false };
let currentView = 'dashboard';
let toastTimer;
let currentUser = null;
let csrfToken = '';

const pageContent = document.getElementById('pageContent');
const modalLayer = document.getElementById('modalLayer');
const modalCard = document.getElementById('modalCard');
const toastElement = document.getElementById('toast');
const authScreen = document.getElementById('authScreen');
const appShell = document.getElementById('appShell');
const loginForm = document.getElementById('loginForm');
const loginMessage = document.getElementById('loginMessage');
const casdoorLoginButton = document.getElementById('casdoorLoginButton');

const viewTitles = {
  dashboard: 'Command center',
  incidents: 'Incidents',
  patrols: 'Patrols & tours',
  officers: 'Officers',
  sites: 'Sites & posts',
  reports: 'Reports',
};

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);
}

async function apiRequest(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (options.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  if (!['GET', 'HEAD'].includes(String(options.method || 'GET').toUpperCase()) && csrfToken) {
    headers.set('X-CSRF-Token', csrfToken);
  }
  const response = await fetch(path, { ...options, headers, credentials: 'same-origin', cache: 'no-store' });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload?.error?.message || 'The request could not be completed.');
    error.status = response.status;
    throw error;
  }
  return payload;
}

function setTheme(theme) {
  const selectedTheme = theme === 'dark' ? 'dark' : 'light';
  document.documentElement.dataset.theme = selectedTheme;
  const themeColor = document.querySelector('meta[name="theme-color"]');
  if (themeColor) themeColor.content = selectedTheme === 'dark' ? '#101923' : '#f4f7f8';

  try { localStorage.setItem('northstar-theme', selectedTheme); } catch { /* Theme preference is optional. */ }
  document.querySelectorAll('[data-action="toggle-theme"]').forEach((button) => {
    const nextTheme = selectedTheme === 'dark' ? 'light' : 'dark';
    button.setAttribute('aria-checked', String(selectedTheme === 'dark'));
    button.setAttribute('aria-label', 'Switch to ' + nextTheme + ' theme');
    button.setAttribute('title', 'Switch to ' + nextTheme + ' theme');
  });
}

function toggleTheme() {
  setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
}

function showLogin(message = '') {
  currentUser = null;
  csrfToken = '';
  currentView = 'dashboard';
  state = { incidents: [], officers: [], sites: [], tours: [], activity: [], incidentFilter: 'All', demoDataControls: false };
  closeModal();
  authScreen.hidden = false;
  appShell.hidden = true;
  if (loginMessage) {
    loginMessage.textContent = message;
    loginMessage.hidden = !message;
  }
}

function displayUser(user) {
  const initials = String(user.name || user.email).split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
  document.querySelectorAll('.profile-label strong').forEach((node) => { node.textContent = user.name; });
  document.querySelectorAll('.profile-label small').forEach((node) => { node.textContent = user.role + ' · ' + user.tenantName; });
  document.querySelectorAll('.avatar').forEach((node) => { node.textContent = initials; });
  const tenant = document.querySelector('.tenant-copy strong');
  if (tenant) tenant.textContent = user.tenantName;
  const sidebarName = document.querySelector('.user-copy strong');
  if (sidebarName) sidebarName.textContent = user.name;
  const sidebarRole = document.querySelector('.user-copy small');
  if (sidebarRole) sidebarRole.textContent = user.role + ' · ' + user.email;
  const service = document.querySelector('.service-status');
  if (service) {
    service.querySelector('strong').textContent = 'DATABASE CONNECTED';
    service.querySelector('small').textContent = 'Authenticated workspace';
    service.classList.add('connected');
  }
  const connectedPill = document.getElementById('connectionPill');
  if (connectedPill) connectedPill.textContent = user.tenantName;
}

async function loadWorkspace() {
  const data = await apiRequest('/api/state');
  state = { ...data, incidentFilter: state.incidentFilter || 'All' };
  render();
}

async function enterWorkspace(user, token) {
  currentUser = user;
  csrfToken = token;
  displayUser(user);
  try {
    await loadWorkspace();
    authScreen.hidden = true;
    appShell.hidden = false;
  } catch (error) {
    showLogin(error.status === 401 ? 'Your session expired. Please sign in again.' : 'The database is unavailable. Check the server and database, then try again.');
  }
}

async function initialize() {
  let theme = 'light';
  try { theme = localStorage.getItem('northstar-theme') || 'light'; } catch { /* Theme preference is optional. */ }
  setTheme(theme);
  const signInUrl = new URL(window.location.href);
  const ssoFailed = signInUrl.searchParams.get('sso') === 'failed';
  if (signInUrl.searchParams.has('sso')) {
    signInUrl.searchParams.delete('sso');
    history.replaceState(null, '', signInUrl.pathname + signInUrl.search + signInUrl.hash);
  }
  try {
    const provider = await apiRequest('/api/auth/casdoor/status');
    if (casdoorLoginButton) casdoorLoginButton.hidden = !provider.enabled;
  } catch {
    if (casdoorLoginButton) casdoorLoginButton.hidden = true;
  }
  try {
    const session = await apiRequest('/api/auth/session');
    if (session.user) await enterWorkspace(session.user, session.csrfToken);
    else showLogin(ssoFailed ? 'Casdoor sign-in could not be completed. Check the account and try again.' : '');
  } catch {
    showLogin('The service is unavailable. Check the server and database, then try again.');
  }
}

function showToast(message) {
  toastElement.textContent = message;
  toastElement.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastElement.classList.remove('visible'), 2800);
}

function openCount() {
  return state.incidents.filter((incident) => incident.status !== 'resolved').length;
}

function pageHeading(eyebrow, title, subtitle, actions = '') {
  return `<div class="page-heading">
    <div><div class="page-eyebrow">${eyebrow}</div><h1 class="page-title">${title}</h1><p class="page-subtitle">${subtitle}</p></div>
    <div class="heading-actions">${actions}</div>
  </div>`;
}

function newDispatchButton() {
  return `<button class="primary-btn" data-action="new-dispatch"><span class="button-plus">＋</span> New dispatch</button>`;
}

function statusChip(status) {
  const labels = { open: 'OPEN', assigned: 'ASSIGNED', resolved: 'RESOLVED' };
  return `<span class="status-chip ${status === 'assigned' ? 'assigned' : ''} ${status === 'resolved' ? 'resolved' : ''}"><span class="status-dot"></span>${labels[status] || 'OPEN'}</span>`;
}

function severityLabel(severity) {
  return severity === 'critical' ? '<span class="priority">● CRITICAL</span>' : `${severity.toUpperCase()} PRIORITY`;
}

function incidentRow(incident) {
  return `<article class="incident-row" role="button" tabindex="0" data-action="open-incident" data-id="${escapeHtml(incident.id)}" aria-label="Open ${escapeHtml(incident.title)}">
    <span class="severity-bar ${escapeHtml(incident.severity)}"></span>
    <div class="incident-copy">
      <div class="incident-type">${severityLabel(incident.severity)} <span class="meta-separator">·</span> ${escapeHtml(incident.type)}</div>
      <div class="incident-title">${escapeHtml(incident.title)}</div>
      <div class="incident-meta"><span>${escapeHtml(incident.site)}</span><span class="meta-separator">·</span><span>${escapeHtml(incident.location)}</span></div>
    </div>
    <div class="incident-trailing"><span class="age-text">${escapeHtml(incident.opened)}</span>${statusChip(incident.status)}</div>
  </article>`;
}

function incidentCard(incident) {
  return `<article class="incident-card" tabindex="0" role="button" data-action="open-incident" data-id="${escapeHtml(incident.id)}" aria-label="Open ${escapeHtml(incident.title)}">
    <div class="incident-card-top"><div class="incident-type"><span class="severity-bar ${escapeHtml(incident.severity)}" ></span>${severityLabel(incident.severity)} · ${escapeHtml(incident.type)}</div>${statusChip(incident.status)}</div>
    <div class="incident-card-title">${escapeHtml(incident.title)}</div>
    <div class="incident-card-description">${escapeHtml(incident.description)}</div>
    <div class="incident-card-footer"><span>${escapeHtml(incident.id)} · ${escapeHtml(incident.opened)}</span><span class="incident-assignee">${incident.assignedOfficer ? `Assigned · ${escapeHtml(incident.assignedOfficer)}` : 'Unassigned'}</span></div>
  </article>`;
}

function mapMarkup() {
  return `<div class="map-stage" role="img" aria-label="Schematic demo map showing Harbour Centre and sample officer positions">
    <div class="map-chip"><span class="map-chip-dot"></span>DEMO SITE · HARBOUR CENTRE</div>
    <svg class="map-svg" viewBox="0 0 850 450" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <path class="map-water" d="M0 358 C148 325 202 386 328 367 C438 350 489 310 592 324 C690 338 768 317 850 298 L850 450 L0 450Z" />
      <path class="map-road-major-edge" d="M-30 96 C183 118 266 76 422 111 S688 149 885 104" />
      <path class="map-road-major" d="M-30 96 C183 118 266 76 422 111 S688 149 885 104" />
      <path class="map-road-edge" d="M58 -10 C89 112 75 217 116 331 S151 425 168 470" />
      <path class="map-road" d="M58 -10 C89 112 75 217 116 331 S151 425 168 470" />
      <path class="map-road-edge" d="M665 -10 C635 102 675 213 648 321 S626 411 604 474" />
      <path class="map-road" d="M665 -10 C635 102 675 213 648 321 S626 411 604 474" />
      <path class="map-road-edge" d="M-20 248 C154 230 298 256 430 236 S663 219 876 248" />
      <path class="map-road" d="M-20 248 C154 230 298 256 430 236 S663 219 876 248" />
      <path class="map-road-edge" d="M335 -20 C319 114 366 191 350 290 S345 399 361 465" />
      <path class="map-road" d="M335 -20 C319 114 366 191 350 290 S345 399 361 465" />
      <rect class="map-block" x="181" y="139" width="104" height="68" rx="7" />
      <rect class="map-park" x="439" y="139" width="123" height="67" rx="7" />
      <rect class="map-block" x="455" y="270" width="118" height="50" rx="6" />
      <rect class="map-block" x="190" y="275" width="105" height="51" rx="6" />
      <path class="map-geofence" d="M348 151 L480 147 L510 208 L493 287 L378 293 L334 242Z" />
      <path class="map-route" d="M409 219 L461 185 L478 229 L421 271 L397 242" />
      <text class="map-building-label" x="204" y="177">BAY PLAZA</text>
      <text class="map-building-label" x="463" y="176">PUBLIC GARDEN</text>
      <text class="map-label" x="168" y="228">KING STREET</text>
      <text class="map-label" x="387" y="124">WELLINGTON STREET</text>
      <text class="map-label" x="489" y="310">FRONT STREET</text>
      <text class="map-label" x="30" y="402">LAKE ONTARIO</text>
    </svg>
    <div class="map-site-pin">⌖</div><div class="map-site-label">HARBOUR CENTRE</div>
    <div class="map-pin pin-maya"><span class="map-pin-bubble"><span>MC</span></span><span class="map-pin-label">Maya Chen <em>· On post</em></span></div>
    <div class="map-pin available pin-jordan"><span class="map-pin-bubble"><span>JL</span></span><span class="map-pin-label">Jordan Lee <em>· Available</em></span></div>
    <div class="map-pin alert pin-alert"><span class="map-pin-bubble"><span>!</span></span></div>
    <div class="map-control-stack"><button class="map-control" aria-label="Zoom in" data-action="map-zoom">+</button><button class="map-control" aria-label="Zoom out" data-action="map-zoom">−</button></div>
  </div>
  <div class="map-legend"><span class="legend-item"><i class="legend-dot"></i>On post</span><span class="legend-item"><i class="legend-dot green"></i>Available</span><span class="legend-item"><i class="legend-dot red"></i>Incident</span><span class="legend-item"><i class="legend-line"></i>Patrol route</span><span class="schematic-note">Schematic demo map · Not live GPS</span></div>`;
}

function widthClass(value) {
  const numeric = Number(value);
  const bounded = Number.isFinite(numeric) ? Math.max(0, Math.min(numeric, 100)) : 0;
  return 'width-' + Math.round(bounded / 5) * 5;
}

function batteryMarkup(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return '<span class="battery-unavailable">—</span>';
  const battery = Math.max(0, Math.min(100, numeric));
  const style = battery < 35 ? 'mid' : '';
  return '<span class="battery"><span class="battery-icon"><i class="battery-fill ' + style + ' ' + widthClass(Math.max(10, battery)) + '"></i></span>' + battery + '%</span>';
}
function rosterTable(officers, compact = false) {
  const rows = officers.map((officer) => {
    const statusClass = officer.status === 'Available' ? 'off-post' : '';
    return `<tr>
      <td><div class="officer-cell"><span class="officer-initials">${escapeHtml(officer.initials)}</span><span class="officer-name">${escapeHtml(officer.name)}<small>${escapeHtml(officer.id)} · ${escapeHtml(officer.role)}</small></span></div></td>
      <td><span class="presence ${statusClass}"><i class="presence-dot"></i>${escapeHtml(officer.status)}</span></td>
      <td>${escapeHtml(officer.site)}</td>
      <td>${escapeHtml(officer.post)}</td>
      <td>${batteryMarkup(officer.battery)}</td>
      <td>${escapeHtml(officer.ping)}</td>
    </tr>`;
  }).join('');
  return `<div class="table-scroll"><table class="data-table"><thead><tr><th>OFFICER</th><th>STATUS</th><th>SITE</th><th>ASSIGNMENT</th><th>BATTERY</th><th>LAST UPDATE</th></tr></thead><tbody>${rows || `<tr><td class="muted-empty" colspan="6">No officer records.</td></tr>`}</tbody></table></div>`;
}

function timelineMarkup() {
  return `<div class="timeline">${state.activity.slice(0, 5).map((item) => `<div class="timeline-item"><span class="timeline-marker">${escapeHtml(item.icon)}</span><div class="timeline-copy"><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.detail)}</p></div><time class="timeline-time">${escapeHtml(item.time)}</time></div>`).join('')}</div>`;
}

function renderDashboard() {
  const incidents = state.incidents.filter((incident) => incident.status !== 'resolved').slice(0, 4);
  const open = openCount();
  const onDuty = state.officers.filter((officer) => officer.status !== 'Off duty').length;
  const exceptions = state.tours.filter((tour) => tour.status === 'exception').length;
  const siteName = state.sites[0]?.name || 'No sites configured';
  const today = new Date().toLocaleDateString('en-CA', { weekday: 'long', month: 'long', day: 'numeric' }).toUpperCase();
  return `${pageHeading(today, 'Operations overview', 'Current records from your authenticated operations workspace.', `<button class="site-select" data-action="show-info"><span class="pin">⌖</span> ${escapeHtml(siteName)} <span class="chevron">⌄</span></button>${newDispatchButton()}`)}
    <section class="metrics-grid" aria-label="Operations summary">
      <article class="metric-card"><div class="metric-head"><span>OFFICER ROSTER</span><span class="metric-icon green">♙</span></div><div class="metric-value-row"><strong class="metric-value">${onDuty}</strong></div><div class="metric-foot"><b>Database records</b> · device presence is not live</div></article>
      <article class="metric-card"><div class="metric-head"><span>OPEN INCIDENTS</span><span class="metric-icon red">!</span></div><div class="metric-value-row"><strong class="metric-value">${open}</strong><span class="metric-trend warn">${open ? 'Needs review' : 'All clear'}</span></div><div class="metric-foot"><b>${state.incidents.filter((incident) => incident.severity === 'critical' && incident.status !== 'resolved').length} critical</b> · ${state.incidents.filter((incident) => incident.status === 'assigned').length} assigned</div></article>
      <article class="metric-card"><div class="metric-head"><span>PATROL EXCEPTIONS</span><span class="metric-icon amber">◷</span></div><div class="metric-value-row"><strong class="metric-value">${exceptions}</strong></div><div class="metric-foot">Tour records saved on the server</div></article>
      <article class="metric-card"><div class="metric-head"><span>SHIFT COVERAGE</span><span class="metric-icon blue">▧</span></div><div class="metric-value-row"><strong class="metric-value">—</strong></div><div class="metric-foot">Shift planning is not configured</div></article>
    </section>
    <section class="dashboard-grid">
      <article class="panel"><header class="panel-header"><div class="panel-title"><span class="panel-title-icon">⌖</span> Site plan preview <small>· NO LIVE POSITIONS</small></div><button class="panel-link" data-view="officers">View roster <span>→</span></button></header><div class="panel-body">${mapMarkup()}</div></article>
      <article class="panel"><header class="panel-header"><div class="panel-title"><span class="panel-title-icon">◉</span> Incident queue <small>· ${open} OPEN</small></div><button class="panel-link" data-view="incidents">View all <span>→</span></button></header><div class="incident-list">${incidents.length ? incidents.map(incidentRow).join('') : '<div class="incident-empty">No open incidents.</div>'}</div></article>
    </section>
    <section class="lower-grid">
      <article class="panel"><header class="panel-header"><div class="panel-title"><span class="panel-title-icon">♙</span> Officer roster <small>· DATABASE RECORDS</small></div><button class="panel-link" data-view="officers">Full roster <span>→</span></button></header>${rosterTable(state.officers.slice(0, 4), true)}</article>
      <article class="panel"><header class="panel-header"><div class="panel-title"><span class="panel-title-icon">⌁</span> Activity feed <small>· AUDIT EVENTS</small></div><span class="status-chip resolved">DATABASE</span></header><div class="panel-body">${timelineMarkup()}</div></article>
    </section>`;
}
function renderIncidents() {
  const filters = ['All', 'Open', 'Assigned', 'Resolved'];
  const incidents = state.incidents.filter((incident) => state.incidentFilter === 'All' || incident.status === state.incidentFilter.toLowerCase());
  return `${pageHeading('RESPONSE WORKFLOW', 'Incident management', 'Create, assign, and close incident records.', `<button class="secondary-btn" data-action="show-info">Export view <span>↗</span></button>${newDispatchButton()}`)}
    <div class="view-toolbar"><div class="filter-row">${filters.map((filter) => `<button class="filter-chip ${state.incidentFilter === filter ? 'active' : ''}" data-action="incident-filter" data-filter="${filter}">${filter}${filter === 'Open' ? ` (${openCount()})` : ''}</button>`).join('')}</div><span class="form-hint">Changes are recorded on the server with an audit event.</span></div>
    <section class="full-incident-grid">${incidents.length ? incidents.map(incidentCard).join('') : '<div class="panel muted-empty">No incidents match this filter.</div>'}</section>`;
}

function renderPatrols() {
  const tours = state.tours || [];
  const exceptions = tours.filter((tour) => tour.status === 'exception').length;
  const checkpointCount = tours.reduce((sum, tour) => sum + tour.total, 0);
  const completedCount = tours.reduce((sum, tour) => sum + tour.complete, 0);
  return `${pageHeading('TOUR COMPLIANCE', 'Patrols & tours', 'Tour records load from the operations service. Checkpoint activity is not connected to field devices.', `<button class="secondary-btn" data-action="show-info">Tour templates <span>⌄</span></button><button class="primary-btn" data-action="show-info"><span class="button-plus">＋</span> Create tour</button>`)}
    <section class="metrics-grid">
      <article class="metric-card"><div class="metric-head"><span>TOUR RECORDS</span><span class="metric-icon green">◎</span></div><div class="metric-value-row"><strong class="metric-value">${tours.length}</strong></div><div class="metric-foot">Saved in the operations workspace</div></article>
      <article class="metric-card"><div class="metric-head"><span>CHECKPOINTS</span><span class="metric-icon blue">✓</span></div><div class="metric-value-row"><strong class="metric-value">${completedCount}</strong><span class="metric-trend">of ${checkpointCount}</span></div><div class="metric-foot">Seed/demo counts until device sync is added</div></article>
      <article class="metric-card"><div class="metric-head"><span>TOUR EXCEPTIONS</span><span class="metric-icon amber">!</span></div><div class="metric-value-row"><strong class="metric-value">${exceptions}</strong></div><div class="metric-foot">Requires real patrol event integration</div></article>
      <article class="metric-card"><div class="metric-head"><span>LIVE CHECK-INS</span><span class="metric-icon red">↗</span></div><div class="metric-value-row"><strong class="metric-value">—</strong></div><div class="metric-foot">No officer device is connected</div></article>
    </section>
    <div class="view-toolbar"><div class="filter-row"><button class="filter-chip active">All tours</button></div><span class="form-hint">Sample tours remain illustrative until replaced with verified schedules.</span></div>
    <section class="patrol-list">${tours.length ? tours.map((tour) => `<article class="patrol-card"><div class="patrol-card-head"><div><div class="patrol-name">${escapeHtml(tour.name)}</div><div class="patrol-site">${escapeHtml(tour.site)} · Assigned to ${escapeHtml(tour.officer)}</div></div><span class="status-chip ${tour.status === 'exception' ? '' : 'assigned'}"><span class="status-dot"></span>${tour.status === 'exception' ? 'EXCEPTION' : tour.status === 'completed' ? 'COMPLETE' : 'IN PROGRESS'}</span></div><div class="patrol-stats"><span class="patrol-stat"><strong>${escapeHtml(tour.window)}</strong><small>TOUR WINDOW</small></span><span class="patrol-stat"><strong>${tour.complete} / ${tour.total}</strong><small>CHECKPOINTS</small></span><span class="patrol-stat"><strong>${tour.total ? Math.round(tour.complete / tour.total * 100) : 0}%</strong><small>COMPLETE</small></span></div><div class="progress-track"><div class="progress-fill ${widthClass(tour.total ? tour.complete / tour.total * 100 : 0)}"></div></div><div class="tour-checkpoints">${tour.checkpoints.map((point, pointIndex) => `<span class="tour-checkpoint ${pointIndex < tour.complete ? 'done' : tour.status === 'exception' && pointIndex === tour.complete ? 'missed' : ''}"><i class="tour-point-dot"></i>${escapeHtml(point)}</span>`).join('')}</div></article>`).join('') : '<div class="panel muted-empty">No patrol tours configured.</div>'}</section>`;
}
function renderOfficers() {
  const onDuty = state.officers.filter((officer) => officer.status !== 'Off duty').length;
  const available = state.officers.filter((officer) => officer.status === 'Available').length;
  return `${pageHeading('FIELD PERSONNEL', 'Officer roster', 'Officer records are stored securely. Device presence is not connected.', `<button class="secondary-btn" data-action="show-info">Qualifications <span>⌄</span></button><button class="primary-btn" data-action="show-info"><span class="button-plus">＋</span> Add officer</button>`)}
    <section class="metrics-grid">
      <article class="metric-card"><div class="metric-head"><span>ROSTERED OFFICERS</span><span class="metric-icon green">♙</span></div><div class="metric-value-row"><strong class="metric-value">${onDuty}</strong></div><div class="metric-foot">Database roster count</div></article>
      <article class="metric-card"><div class="metric-head"><span>AVAILABLE</span><span class="metric-icon blue">◌</span></div><div class="metric-value-row"><strong class="metric-value">${available}</strong></div><div class="metric-foot">Status saved securely</div></article>
      <article class="metric-card"><div class="metric-head"><span>DEVICE CHECK-IN</span><span class="metric-icon green">⌁</span></div><div class="metric-value-row"><strong class="metric-value">—</strong></div><div class="metric-foot">No officer devices are reporting</div></article>
      <article class="metric-card"><div class="metric-head"><span>LICENSES</span><span class="metric-icon amber">▤</span></div><div class="metric-value-row"><strong class="metric-value">—</strong></div><div class="metric-foot">Qualification records are not configured</div></article>
    </section>
    <article class="panel"><header class="panel-header"><div class="panel-title">Officer records <small>· SECURE SERVICE</small></div></header>${rosterTable(state.officers)}</article>
    <div class="connection-banner"><span>i</span><div><strong>No live presence feed</strong>Last-seen times and battery values are database fields; they do not update from a device until an authenticated mobile sync service is connected.</div></div>`;
}

function renderSites() {
  const siteCards = state.sites.map((site) => {
    const assigned = state.officers.filter((officer) => officer.site === site.name);
    return `<section class="site-detail">
      <article class="site-hero"><span class="page-eyebrow">CLIENT SITE · ${escapeHtml(site.status)}</span><h2>${escapeHtml(site.name)}</h2><p>${escapeHtml([site.address, site.city, site.region, site.site_type].filter(Boolean).join(' · '))}</p><div class="site-detail-grid"><div class="site-detail-stat"><strong>${assigned.length}</strong><small>OFFICER RECORDS</small></div><div class="site-detail-stat"><strong>${escapeHtml(site.contract_window || 'Not configured')}</strong><small>CONTRACT WINDOW</small></div><div class="site-detail-stat"><strong>${site.geofence_m} m</strong><small>DATABASE FENCE VALUE</small></div></div></article>
      <article class="panel"><header class="panel-header"><div class="panel-title">Site overview</div></header><div class="panel-body"><div class="site-info-list"><div class="site-info-row"><span>Client account</span><strong>${escapeHtml(site.client_name || 'Not configured')}</strong></div><div class="site-info-row"><span>Primary contact</span><strong>${escapeHtml([site.contact_name, site.contact_phone].filter(Boolean).join(' · ') || 'Not configured')}</strong></div><div class="site-info-row"><span>Operating region</span><strong>${escapeHtml([site.city, site.region].filter(Boolean).join(' · '))}</strong></div><div class="site-info-row"><span>Site status</span><strong>${escapeHtml(site.status)}</strong></div></div></div></article>
      <article class="panel"><header class="panel-header"><div class="panel-title">Assigned officers</div></header>${rosterTable(assigned)}</article>
    </section>`;
  }).join('');
  const firstSite = state.sites[0]?.name || 'No site selected';
  return `${pageHeading('SITE DIRECTORY', 'Sites & posts', 'Site records load from the operations service. Map geometry remains a non-operational schematic.', `<span class="site-select"><span class="pin">⌖</span> ${escapeHtml(firstSite)}</span>`)}
    ${siteCards || '<div class="panel muted-empty">No sites are configured for this workspace.</div>'}
    <article class="panel site-map-panel"><header class="panel-header"><div class="panel-title">Schematic map preview <small>· NOT A LIVE MAP</small></div></header><div class="panel-body">${mapMarkup()}<div class="connection-banner"><span>i</span><div><strong>Map integration is not configured</strong>Replace this illustration with a verified site plan and authorized location service before operational use.</div></div></div></article>`;
}
function renderReports() {
  const open = openCount();
  const resolved = state.incidents.filter((incident) => incident.status === 'resolved').length;
  const assigned = state.incidents.filter((incident) => incident.status === 'assigned').length;
  const total = state.incidents.length;
  const openPercent = total ? Math.round(open / total * 100) : 0;
  const assignedPercent = total ? Math.round(assigned / total * 100) : 0;
  const resolvedPercent = total ? Math.round(resolved / total * 100) : 0;
  return `${pageHeading('OPERATIONAL INSIGHTS', 'Reports & performance', 'Incident counts use workspace records. Historical KPIs are not configured.', `<button class="secondary-btn" data-action="show-info">Reporting status <span>↗</span></button>`)}
    <section class="metrics-grid">
      <article class="metric-card"><div class="metric-head"><span>OPEN INCIDENTS</span><span class="metric-icon red">!</span></div><div class="metric-value-row"><strong class="metric-value">${open}</strong></div><div class="metric-foot">Current database records</div></article>
      <article class="metric-card"><div class="metric-head"><span>ASSIGNED INCIDENTS</span><span class="metric-icon blue">↗</span></div><div class="metric-value-row"><strong class="metric-value">${assigned}</strong></div><div class="metric-foot">Current database records</div></article>
      <article class="metric-card"><div class="metric-head"><span>RESOLVED INCIDENTS</span><span class="metric-icon green">✓</span></div><div class="metric-value-row"><strong class="metric-value">${resolved}</strong></div><div class="metric-foot">Loaded incident history</div></article>
      <article class="metric-card"><div class="metric-head"><span>RESPONSE TIME</span><span class="metric-icon amber">◷</span></div><div class="metric-value-row"><strong class="metric-value">—</strong></div><div class="metric-foot">Not calculated yet</div></article>
    </section>
    <section class="report-grid"><article class="panel chart-panel"><div class="chart-title">Operational reporting is not enabled</div><div class="chart-subtitle">This dashboard does not yet calculate shifts, patrol completion, response-time trends, or client SLAs from verified records.</div><div class="connection-banner"><span>i</span><div><strong>Connect verified operational workflows</strong>Configure shift, patrol event, and SLA records before publishing performance reports.</div></div></article><article class="panel chart-panel"><div class="chart-title">Incident status</div><div class="sla-row"><span>Open</span><div class="sla-track"><div class="sla-fill amber ${widthClass(openPercent)}"></div></div><span class="sla-value">${open}</span></div><div class="sla-row"><span>Assigned</span><div class="sla-track"><div class="sla-fill blue ${widthClass(assignedPercent)}"></div></div><span class="sla-value">${assigned}</span></div><div class="sla-row"><span>Resolved</span><div class="sla-track"><div class="sla-fill ${widthClass(resolvedPercent)}"></div></div><span class="sla-value">${resolved}</span></div></article></section>`;
}
function render() {
  const renderers = {
    dashboard: renderDashboard,
    incidents: renderIncidents,
    patrols: renderPatrols,
    officers: renderOfficers,
    sites: renderSites,
    reports: renderReports,
  };
  pageContent.innerHTML = (renderers[currentView] || renderDashboard)();
  document.getElementById('breadcrumbTitle').textContent = viewTitles[currentView] || viewTitles.dashboard;
  document.getElementById('incidentNavCount').textContent = String(openCount());
  document.querySelectorAll('.nav-item[data-view]').forEach((button) => {
    button.classList.toggle('active', button.dataset.view === currentView);
    button.setAttribute('aria-current', button.dataset.view === currentView ? 'page' : 'false');
  });
}

function switchView(view) {
  if (!viewTitles[view]) return;
  currentView = view;
  document.querySelector('.sidebar').classList.remove('mobile-open');
  render();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function openModal(content) {
  modalCard.innerHTML = content;
  modalLayer.hidden = false;
  document.body.classList.add('modal-open');
  const focusable = modalCard.querySelector('input, select, textarea, button');
  if (focusable) setTimeout(() => focusable.focus(), 20);
}

function closeModal() {
  modalLayer.hidden = true;
  modalCard.innerHTML = '';
  document.body.classList.remove('modal-open');
}

function openDispatchModal() {
  if (!state.sites.length) {
    showToast('Add an active site before creating a dispatch.');
    return;
  }
  const siteOptions = state.sites.map((site) =>
    '<option value="' + escapeHtml(site.id) + '">' + escapeHtml(site.name) + '</option>',
  ).join('');
  openModal('<div class="modal-head"><div><h2 id="modalTitle">Create dispatch ticket</h2><p>Save a new incident to the operations database.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div>' +
    '<form id="dispatchForm">' +
      '<div class="form-field"><label for="dispatchType">INCIDENT TYPE</label><select id="dispatchType" name="type" required><option>Alarm response</option><option>Medical emergency</option><option>Noise complaint</option><option>Access control</option><option>Suspicious person</option><option>Property damage</option></select></div>' +
      '<div class="form-field"><label for="dispatchPriority">PRIORITY</label><select id="dispatchPriority" name="severity"><option value="high">High</option><option value="critical">Critical</option><option value="medium">Medium</option><option value="low">Low</option></select></div>' +
      '<div class="form-field"><label for="dispatchSite">SITE</label><select id="dispatchSite" name="siteId" required>' + siteOptions + '</select></div>' +
      '<div class="form-field"><label for="dispatchLocation">LOCATION</label><input id="dispatchLocation" name="location" required maxlength="90" placeholder="e.g. Level 4 · North stairwell" /></div>' +
      '<div class="form-field"><label for="dispatchSummary">SUMMARY</label><input id="dispatchSummary" name="title" required maxlength="100" placeholder="Briefly describe the incident" /></div>' +
      '<div class="form-field"><label for="dispatchDetails">DISPATCH NOTES</label><textarea id="dispatchDetails" name="description" maxlength="800" placeholder="Add relevant response notes"></textarea></div>' +
      '<div class="form-hint">This saves an incident record. It does not alert a guard device.</div>' +
      '<div class="modal-actions"><button class="secondary-btn" type="button" data-action="close-modal">Cancel</button><button class="primary-btn" type="submit">Save incident</button></div>' +
    '</form>');
}

function openIncidentModal(id) {
  const incident = state.incidents.find((item) => item.id === id);
  if (!incident) return;
  const actionButtons = incident.status === 'resolved'
    ? '<span class="status-chip resolved"><span class="status-dot"></span>RESOLVED</span>'
    : '<button class="secondary-btn" type="button" data-action="resolve-incident" data-id="' + escapeHtml(id) + '">Mark resolved</button>' +
      (incident.assignedOfficer ? '' : '<button class="primary-btn" type="button" data-action="assign-incident" data-id="' + escapeHtml(id) + '">Assign available officer</button>');
  openModal(`<div class="modal-head"><div><div class="incident-type"><span class="severity-bar ${escapeHtml(incident.severity)}" ></span>${severityLabel(incident.severity)} · ${escapeHtml(incident.type)}</div><h2 id="modalTitle" class="incident-modal-title">${escapeHtml(incident.title)}</h2><p>${escapeHtml(incident.id)} · ${escapeHtml(incident.opened)}</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div>
    <div class="detail-block"><small>STATUS & ASSIGNMENT</small><p>${statusChip(incident.status)}${incident.assignedOfficer ? ' <span class="incident-assignee">' + escapeHtml(incident.assignedOfficer) + '</span>' : ' <span class="form-hint">No officer assigned</span>'}</p></div>
    <div class="detail-block"><small>SITE & LOCATION</small><p>${escapeHtml(incident.site)}<br />${escapeHtml(incident.location)}</p></div>
    <div class="detail-block"><small>REPORT SUMMARY</small><p>${escapeHtml(incident.description)}</p></div>
    <div class="connection-banner"><span>i</span><div><strong>Saved record</strong>The action is audited. No officer device or monitoring service is connected.</div></div>
    <div class="modal-actions"><button class="secondary-btn" type="button" data-action="close-modal">Close</button>${actionButtons}</div>`);
}

function showInfoModal() {
  const demoControls = state.demoDataControls
    ? '<div class="demo-controls"><div><h3>Fictional demo data</h3><p>Load sample sites, officers, patrols, incidents, and activity, or remove only records marked as demo.</p></div><div class="demo-actions"><button class="secondary-btn" type="button" data-action="load-demo">＋ Add demo data</button><button class="danger-btn" type="button" data-action="confirm-remove-demo">Remove demo data</button></div></div>'
    : '';
  openModal('<div class="modal-head"><div><h2 id="modalTitle">Workspace connection</h2><p>Authenticated operations workspace</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div>' +
    '<div class="detail-block"><small>WORKSPACE</small><p>Incidents, roster, sites, patrol summaries, and audit events load from your secure operations workspace.</p></div>' +
    '<div class="detail-block"><small>DISPATCH</small><p>Creating, assigning, and resolving an incident changes a database record. No officer device, paging, SMS, email, or monitoring center is notified.</p></div>' +
    '<div class="detail-block"><small>NOT CONNECTED</small><p>Live GPS, mobile sync, site geofences, shift planning, qualifications, and verified performance reporting still require separate production workflows.</p></div>' +
    demoControls +
    '<div class="modal-actions"><button class="primary-btn" type="button" data-action="close-modal">Got it</button></div>');
}

function confirmRemoveDemoData() {
  openModal('<div class="modal-head"><div><h2 id="modalTitle">Remove demo data?</h2><p>This will remove fictional sample records from this workspace.</p></div><button class="modal-close" type="button" data-action="close-modal" aria-label="Close">×</button></div>' +
    '<div class="connection-banner"><span>!</span><div><strong>Only records marked as demo are selected.</strong>If a sample site or officer is linked to an operational record, removal will stop and explain what needs attention.</div></div>' +
    '<form id="removeDemoForm"><label class="demo-confirm-label"><input id="removeDemoConfirm" type="checkbox" required /> I understand this removes all tagged demo records in this workspace.</label>' +
    '<div class="modal-actions"><button class="secondary-btn" type="button" data-action="close-modal">Cancel</button><button class="danger-btn" type="submit">Remove demo data</button></div></form>');
}

async function manageDemoData(action) {
  const button = action === 'remove-demo'
    ? modalCard.querySelector('#removeDemoForm button[type="submit"]')
    : modalCard.querySelector('[data-action="' + action + '"]');
  if (button) button.disabled = true;
  try {
    const removing = action === 'remove-demo';
    const result = await apiRequest('/api/demo-data/' + (removing ? 'remove' : 'load'), {
      method: 'POST', body: JSON.stringify({ confirm: removing ? 'REMOVE' : 'LOAD' }),
    });
    closeModal();
    await loadWorkspace();
    const count = Object.values(result.counts || {}).reduce((sum, value) => sum + Number(value || 0), 0);
    showToast(removing ? count + ' demo records removed.' : 'Fictional demo data is ready.');
  } catch (error) {
    showToast(error.message);
    if (button) button.disabled = false;
  }
}

async function createDispatch(form) {
  const values = Object.fromEntries(new FormData(form).entries());
  try {
    const result = await apiRequest('/api/incidents', { method: 'POST', body: JSON.stringify(values) });
    closeModal();
    await loadWorkspace();
    showToast(result.id + ' saved in the operations workspace.');
  } catch (error) {
    showToast(error.message);
  }
}

async function updateIncident(id, action) {
  try {
    const result = await apiRequest('/api/incidents/' + encodeURIComponent(id), {
      method: 'PATCH',
      body: JSON.stringify({ action }),
    });
    closeModal();
    await loadWorkspace();
    showToast(result.message);
  } catch (error) {
    showToast(error.message);
  }
}

function assignIncident(id) {
  return updateIncident(id, 'assign');
}

function resolveIncident(id) {
  return updateIncident(id, 'resolve');
}

document.querySelectorAll('.nav-item[data-view]').forEach((button) => {
  button.addEventListener('click', () => switchView(button.dataset.view));
});

document.addEventListener('click', (event) => {
  const target = event.target.closest('[data-action]');
  if (!target) return;
  const { action, id } = target.dataset;
  if (action === 'toggle-theme') toggleTheme();
  else if (action === 'new-dispatch') openDispatchModal();
  else if (action === 'open-incident') openIncidentModal(id);
  else if (action === 'close-modal') closeModal();
  else if (action === 'show-info') showInfoModal();
  else if (action === 'load-demo') manageDemoData('load-demo');
  else if (action === 'confirm-remove-demo') confirmRemoveDemoData();
  else if (action === 'assign-incident') assignIncident(id);
  else if (action === 'resolve-incident') resolveIncident(id);
  else if (action === 'incident-filter') { state.incidentFilter = target.dataset.filter; render(); }
  else if (action === 'toggle-nav') document.querySelector('.sidebar').classList.toggle('mobile-open');
  else if (action === 'map-zoom') showToast('The site plan is a visual preview.');
  else if (action === 'logout') {
    apiRequest('/api/auth/logout', { method: 'POST', body: '{}' })
      .catch(() => {})
      .finally(() => showLogin());
  }
});

document.addEventListener('submit', async (event) => {
  if (event.target.id === 'loginForm') {
    event.preventDefault();
    const button = loginForm.querySelector('button[type="submit"]');
    button.disabled = true;
    loginMessage.hidden = true;
    const values = Object.fromEntries(new FormData(loginForm).entries());
    try {
      const session = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(values),
      });
      loginForm.reset();
      await enterWorkspace(session.user, session.csrfToken);
    } catch (error) {
      loginMessage.textContent = error.message;
      loginMessage.hidden = false;
    } finally {
      button.disabled = false;
    }
    return;
  }
  if (event.target.id === 'dispatchForm') {
    event.preventDefault();
    const button = event.target.querySelector('button[type="submit"]');
    button.disabled = true;
    await createDispatch(event.target);
    button.disabled = false;
    return;
  }
  if (event.target.id === 'removeDemoForm') {
    event.preventDefault();
    if (!document.getElementById('removeDemoConfirm')?.checked) return;
    await manageDemoData('remove-demo');
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !modalLayer.hidden) closeModal();
  if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('[role="button"][data-action="open-incident"]')) {
    event.preventDefault();
    openIncidentModal(event.target.dataset.id);
  }
});

initialize();
